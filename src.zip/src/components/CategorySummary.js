import React, { useEffect, useState } from 'react';
import { fetchCategorySummary } from '../services/api';

console.log("CategorySummary loaded");
const CategorySummary = () => {
    const [data, setData] = useState([]);
    const [Error, setError] = useState(null);

    useEffect(() => {
        const fetchData = async () => {
            try {
                console.log("Fetching data from API...");
                const result = await fetchCategorySummary();
                console.log("API response:", result);
                setData(result);
            } catch (err) {
                console.error("Error fetching data:", err);
                setError('Failed to fetch category summary');
            }
        };
        fetchData();
    }, []);

    if (Error) {
        return <div>{Error}</div>;
    }
    return (
        <div>
            <h2>Category Summary</h2>
            <ul>
                {data.map((item, index) => (
                    <li key={index}>
                        {item.category} - {item.totalAmount}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default CategorySummary;