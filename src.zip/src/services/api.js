import axios from 'axios';  

const apiClient = axios.create({
    baseURL: 'https://localhost:7182/api',
    headers: {
        'Content-Type': 'application/json'
    },


});

export const fetchCategorySummary = async () => {
    const response = await apiClient.get('/Analytics/CategorySummary');
    return response.data;
};